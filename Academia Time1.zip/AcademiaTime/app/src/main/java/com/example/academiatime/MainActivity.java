package com.example.academiatime;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Spinner spinnerMuscleGroup;
    private Spinner spinnerExercise;
    private Button btnStart;
    private Button btnPause;
    private ImageView imageView;
    private TextView countdownTextView;
    private int currentRound = 0;

    private CountDownTimer exerciseTimer;
    private CountDownTimer restTimer;

    private long exerciseTimeRemaining;  // Para armazenar o tempo restante do exercício
    private long restTimeRemaining;      // Para armazenar o tempo restante do descanso

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinnerMuscleGroup = findViewById(R.id.spinnerMuscleGroup);
        spinnerExercise = findViewById(R.id.spinnerExercise);
        btnStart = findViewById(R.id.btnStart);
        btnPause = findViewById(R.id.btnPause);
        imageView = findViewById(R.id.imageView);
        countdownTextView = findViewById(R.id.countdownTextView);

        ArrayAdapter<CharSequence> muscleGroupAdapter = ArrayAdapter.createFromResource(
                this,
                R.array.muscle_groups,
                android.R.layout.simple_spinner_item
        );
        muscleGroupAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMuscleGroup.setAdapter(muscleGroupAdapter);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startTraining();
            }
        });

        btnPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pauseTraining();
            }
        });

        // Adicionar listener para a escolha do grupo muscular
        spinnerMuscleGroup.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // Atualizar o spinner de exercícios com base no grupo muscular selecionado
                updateExerciseSpinner(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Fazer algo aqui, se necessário
            }
        });
    }

    // Método para atualizar o spinner de exercícios com base no grupo muscular selecionado
    private void updateExerciseSpinner(int muscleGroupPosition) {
        int exercisesArrayId = 0;
        int muscleImageResourceId = 0;

        switch (muscleGroupPosition) {
            case 0: // Peito
                exercisesArrayId = R.array.chest_exercises;
                muscleImageResourceId = R.drawable.peito;
                break;
            case 1: // Costas
                exercisesArrayId = R.array.back_exercises;
                muscleImageResourceId = R.drawable.costas;
                break;
            case 2: // Bíceps
                exercisesArrayId = R.array.biceps_exercises;
                muscleImageResourceId = R.drawable.biceps;
                break;
            case 3: // Tríceps
                exercisesArrayId = R.array.triceps_exercises;
                muscleImageResourceId = R.drawable.tricipes;
                break;
            case 4: // Ombro
                exercisesArrayId = R.array.shoulder_exercises;
                muscleImageResourceId = R.drawable.ombro;
                break;
            case 5: // Pernas
                exercisesArrayId = R.array.legs_exercises;
                muscleImageResourceId = R.drawable.pernas;
                break;
        }

        // Define a imagem do grupo muscular
        imageView.setImageResource(muscleImageResourceId);

        ArrayAdapter<CharSequence> exerciseAdapter = ArrayAdapter.createFromResource(
                this,
                exercisesArrayId,
                android.R.layout.simple_spinner_item
        );
        exerciseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerExercise.setAdapter(exerciseAdapter);
    }

    private void startTraining() {
        currentRound = 0;
        performExercise();
    }

    private void performExercise() {
        if (currentRound < 4) {
            currentRound++;

            // Lógica para exibir a contagem regressiva de 45 segundos
            exerciseTimer = new CountDownTimer(exerciseTimeRemaining > 0 ? exerciseTimeRemaining : 45000, 1000) {
                public void onTick(long millisUntilFinished) {
                    exerciseTimeRemaining = millisUntilFinished;
                    countdownTextView.setText("Tempo restante: " + millisUntilFinished / 1000 + "s");
                }

                public void onFinish() {
                    // Lógica para a próxima etapa (descanso)
                    countdownTextView.setText("Descanso!");
                    performRest();
                }
            }.start();
        } else {
            // Treino concluído
            countdownTextView.setText("Treino concluído!");
        }
    }

    private void performRest() {
        // Lógica para exibir a contagem regressiva de 1 minuto durante o descanso
        restTimer = new CountDownTimer(restTimeRemaining > 0 ? restTimeRemaining : 60000, 1000) {
            public void onTick(long millisUntilFinished) {
                restTimeRemaining = millisUntilFinished;
                countdownTextView.setText("Tempo de descanso: " + millisUntilFinished / 1000 + "s");
            }

            public void onFinish() {
                // Lógica para a próxima etapa (próximo exercício)
                countdownTextView.setText("Próximo exercício!");
                performExercise();
            }
        }.start();
    }

    private void pauseTraining() {
        if (exerciseTimer != null) {
            exerciseTimer.cancel();
        }
        if (restTimer != null) {
            restTimer.cancel();
        }
        countdownTextView.setText("Treino pausado");
    }
}
